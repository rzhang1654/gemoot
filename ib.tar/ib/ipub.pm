#!/usr/bin/perl
#################################################
#################################################
###                                           ###
###                IPUB                       ###
###                                           ###   
###           (I)nventory                     ###
###           (P)atch                         ###
###           (U)pgrade                       ###
###           (B)uild                         ###
###                                           ###
#################################################
#################################################
###                                           ###
###                                           ###
###   Front end program for Linux building,   ###
###   patching and upgrading for Exelon       ###
###   Red Hat Satellite managed  hosts        ###
###                                           ###
###                                           ###
#################################################
#################################################
###                                           ###
###   Command Syntax:                         ###
###     Menu driven                           ###
###                                           ###
#################################################
#################################################
###  Initial release   Run Zhang 4-9-19       ###
#################################################
###                                           ###
###             Change log                    ###
###                                           ###
###  10/28/2019  ipub client integration      ###
###                                           ###
###                                           ###
#################################################
#################################################


package ipub;
use strict;
use warnings;
use Getopt::Long;
use Carp qw(croak carp);
use IO::Prompt;
use String::Random;
use Term::ReadKey;
use Term::ANSIColor;
use IO::Tee;
use Capture::Tiny::Extended 'capture';
use File::Slurp;
use File::Copy;
use Exporter qw(import);
our @EXPORT = qw(&satmlg);



#################################################
# main hash
#################################################

my $ops = {
   'i' => \&inventory_rl,
   'p' => \&patch_rl,
   'u' => \&upgrade_rl,
   'b' => \&build_rl,
   'q' => \&exit_lg,
   'm' => \&display_menu,
};

my $RAWHOSTS="/apps/ansible/hosts/data/sathst.raw";
my $SATHSTVRFYBIN="/apps/ansible/bin/sesathst.py";
my $ANSIBLEBIN="/usr/bin/ansible-playbook";
my $ANSIBLEPIN="--vault-password-file=/usr/local/etc/.flat_file ";
my $ENFORCESBLPLY7="/apps/ansible/bin/apbase7.py";
my $ENFORCESBLPLY6="/apps/ansible/bin/apbase6.py";
my $ENFORCEROOT="/apps/ansible/bin/enforceroot.py";
my $RMTVRFYBIN="/apps/ansible/bin/vfyrmt.py";
my $RMTCONFBIN="/apps/ansible/bin/confrmt.py";
my $SBLCONFBIN="/apps/ansible/bin/confsbl.py";
my $SYNCONFBIN="/apps/ansible/bin/confsyn.py";
my $GENREPTBIN="/apps/ansible/bin/genuprept.py";
my $GENPAREPTBIN="/apps/ansible/bin/genparept.py";
my $GENPATCHREPTBIN="/apps/ansible/bin/genparept.py";
my $GENPATCHREPT1BIN="/apps/ansible/bin/genparept1.py";
my $GENPDFBIN="/apps/ansible/bin/genuppdf.py";
my $GENPDF1BIN="/apps/ansible/bin/genuppdf1.py";
my $EMREPTBIN="/apps/ansible/bin/emrpt.py";
my $EMPAREPTBIN="/apps/ansible/bin/emparpt.py";
my $EMPAREPT1BIN="/apps/ansible/bin/emparpt1.py";
my $PREPATSORTBIN="/apps/ansible/bin/prepatchsort.py";
my $CHECKBOOTBIN="/apps/ansible/bin/checkboot.py";
my $PROCESSBOOTBIN="/apps/ansible/bin/processboot.py";
my $PROCESSSBLBIN="/apps/ansible/bin/processsbl.py";
my $PROCESSROOTBIN="/apps/ansible/bin/processroot.py";
my $UPLOADPATCHBIN="/apps/ansible/bin/uploadpatch.py";
my $INSTALLIPUBCBIN="/apps/ansible/bin/installipubc.py";
my $SYNCBKPBIN="/apps/ansible/bin/main_syncbkp.py";
my $PROCBKPENVBIN="/apps/ansible/bin/processbkpenv.py";
my $PROCBKPENVPOSTBIN="/apps/ansible/bin/processbkpenv_post.py";
my $GETKERNELVERBIN="/apps/ansible/bin/getkernelver.py";
my $UPGRADEWREBIN="/apps/ansible/bin/upgradewre.py";
my $UPGRADEWREFINBIN="/apps/ansible/bin/upgradewrefin.py";
my $CHKKERNELPOSTBIN="/apps/ansible/bin/chkkernelpost.py";
my $COMPAREKERVERPOSTBIN="/apps/ansible/bin/comparekernelverpost.py";
my $GETFAILEDLISTBIN="/apps/ansible/bin/getfailedlist.py";
my $CHKSBLSTATBIN="/apps/ansible/bin/chksblstat.py";
my $CHKROOTBIN="/apps/ansible/bin/chkrootstat.py";
my $PROCINVBIN="/apps/ansible/bin/processinv.py";
my $BASEDIR="/apps/ansible/upgrade/";
my $PATCHDIR="/apps/ansible/patch/";
my $SBK6="/apps/ansible/exlib_post/enforce_sbl_rhel6.yml";
my $SBK7="/apps/ansible/exlib_post/enforce_sbl_rhel7.yml";
my $SYNC="/apps/ansible/exlib_post/enforce-pass.yml";

my $TKTNUM;
my $EMAIL;

my $DSTR="NO";
my $ifUpgrade="NO";
my $ifPatch="NO";

#################################################
#
# Process input
#
#################################################

sub processinput {
  my $answer="";

  #prompt "Host name(s) to run on (type Ctrl+d when finished): ";
  print "Host name(s) to run on (type Ctrl+d when finished): \n";

  while (<STDIN>) {
    last if /^END$/;
    #/\S/ or last;
    $_ =~ tr{\n}{ };
    $answer .= $_;
  }

  #$answer =~ s/,/ /g;
  if ($answer ne "")
  {
    $answer =~ s/,/ /g;
  }
  return $answer;
}

#################################################
#
# Process file
#
#################################################

sub processfile {
  my $uplist;
  my @lines;

  while (prompt "Enter host list name (under /osconfigsnapshot/hosts/): ") 
  {
   if ($_ eq 'q')  
   {
     exit;
   }
   else 
   {
    $uplist = "/osconfigsnapshot/hosts/"."$_";
    @lines = grep { /^\w+/ } read_file("$uplist", chomp => 1);
    return @lines;
   }
  }
}


#################################################
#
# Generate random string
#
#################################################

sub getrndstr() 
{
  my $rndrtnstr = String::Random->new;
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime();
  my $dstring = join "-","$year","$mon","$mday";

  $DSTR = "$dstring";

  my $rstring = $rndrtnstr->randregex('\d\d\d\d\d\d\d\d\d\d\d\d');
  my $grstring = join "-","$TKTNUM","$EMAIL","$dstring","$rstring";

  return $grstring;
}


#################################################
#
# Pre check
#
#################################################

sub preupchk() 
{
  my $chkfile = shift;
  my $freespace;

  if ( -s "$chkfile" )
  {
    open CKFILE, "$chkfile" or die $!;
    while (<CKFILE>)
    {
      if ( /(\d{1,3})M/)
      {
        $freespace = $1;
        last;
      }
    }
    close CKFILE;
    if ( $freespace > 50 )
    {
      return "SPOK";
    }
    else
    {
      return "SPSML";
    }
  }
  else
  {
    return "NORECH";
  } 
}


#################################################
#
# Security baseline 
#
#################################################

sub enforcesbl
{
  my $tgthst = shift;
  my $osmajor = shift;
  my $logfile = shift;

  if ( $osmajor eq "6")
  {
     my $ansibleexc6 = join " ","$ANSIBLEBIN","$ANSIBLEPIN","$SBK6","-i","$tgthst,",">$logfile 2>&1";
     system("$ansibleexc6");
  }
  elsif ( $osmajor eq "7")
  {
     my $ansibleexc7 = join " ","$ANSIBLEBIN","$ANSIBLEPIN","$SBK7","-i","$tgthst,",">$logfile 2>&1";
     system("$ansibleexc7");
  }
  else
  {
    "\n\n###### OS version is not supported ######\n\n";
  }
}

#################################################
# root pass
#################################################

sub enforcesyn
{
  my $tgthst = shift;
  my $logfile = shift;

  my $ansibleexc = join " ","$ANSIBLEBIN","$ANSIBLEPIN","$SYNC","-i","$tgthst,",">$logfile 2>&1";

  system("$ansibleexc");
}


#################################################
# Post check
#################################################

sub aftupchk() 
{
  my $chkfile = shift;
  my $rels;
  my $ifsuccess = "FAILED";

  if ( -s "$chkfile" )
  {
    open CKFILE, "$chkfile" or die $!;
    while (<CKFILE>)
    {
      if ( /(\d\.\d\d*)/)
      {
        $rels = $1;
      }
      if ( /empty/ )
      {
        $ifsuccess = "SUCCESS";
      }
    }
    close CKFILE;
    if ( $ifsuccess eq "SUCCESS"  )
    {
      return "$rels";
    }
    else
    {
      return "$ifsuccess";
    }
  }
  else
  {
    return "NORECH";
  } 
}


#################################################
#
# SBL check
#
#################################################

sub sblchk()
{
  my $chkfile = shift;
  my $ifsuccess = "FAILED";

  if ( -s "$chkfile" )
  {
    open CKFILE, "$chkfile" or die $!;
    while (<CKFILE>)
    {
      if ( /empty/ )
      {
        $ifsuccess = "SUCCESS";
        last;
      }
    }
    close CKFILE;
    return "$ifsuccess";
  }
  else
  {
    return "NORECH";
  }
}


#################################################
#
# Syn check
#
#################################################

sub synchk()
{
  my $chkfile = shift;
  my $logfile = shift;
  my $ifsuccess = "FAILED";

  if ( -s "$chkfile" )
  {
    open CKFILE, "$chkfile" or die $!;
    while (<CKFILE>)
    {
      if ( /20/ )
      {
        $ifsuccess = "SUCCESS";
        last;
      }
    }
    close CKFILE;

    if ( $ifsuccess eq "FAILED" )
    {
     if ( -e "$logfile" )
     {
       open LGFILE, "$logfile" or die $!;
       while (<LGFILE>)
       {
         if ( /failed=0/ )
         {
            $ifsuccess = "NONEED";
            last;
         }
       }
       close LGFILE;
     }
    }
    return "$ifsuccess";
  }
  else
  {
    return "NORECH";
  }
}


#################################################
#
# Read mac address
#
#################################################

sub readmacaddress()
{
   my $svrmac = shift;
   my $sdig = "[0-9A-Fa-f]";
   my $ddig= "$sdig$sdig";

   if (  $svrmac =~ /^($ddig([:-])$ddig(\2$ddig){4})$/o )
   {
       return "macok";
   }
   else
   {
   return "macnok";
   }
}


#################################################
#
# Read release
#
#################################################

sub readrelease() 
{
   my $rel = shift;

   if (  $rel =~ / 5\./ )
   {
       return "5";
   }
   elsif (  $rel =~ / 6\./ )
   {
       return "6";
   }
   elsif (  $rel =~ / 7\./ )
   {
       return "7";
   }
   else 
   {
      return "0";
   }
}


#################################################
#
# Menu
#
#################################################

#sub display_menu 
#{
#print <<MENU_END;
#Menu: (enter one)
#----------------------------------------------
#----------------------------------------------
#i - INVENTORY                                +
#p - PATCH                                    +
#u - UPGRADE                                  +
#b - BUILD                                    +
#q - Quit                                     +
#----------------------------------------------
#----------------------------------------------
#MENU_END
#return;
#}

sub display_menu
{
print "\n\n";
print colored("                       ", 'yellow on_magenta'), "\n";
print colored("    i - INVENTORY      ", 'yellow on_magenta'), "\n";
print colored("    p - PATCH          ", 'yellow on_magenta'), "\n";
print colored("    u - UPGRADE        ", 'yellow on_magenta'), "\n";
print colored("    b - BUILD          ", 'yellow on_magenta'), "\n";
print colored("    q - Quit           ", 'yellow on_magenta'), "\n";
print colored("                       ", 'yellow on_magenta'), "\n";
print "\n\n";

return;
}

#################################################
# authentication
#################################################

sub authusr
{
  my ($username, $encrypted) = ( getpwuid 1999 )[0,1];
  my $password;

  print colored("Enter password", 'white on_blue'), ":";

  ReadMode 'noecho';
  $password = ReadLine 0;
  chomp $password;
  ReadMode 'normal';

  if (crypt($password, $encrypted) ne $encrypted) 
  {
    die "\n\n...... Password entered is incorrect ......\n\n";
  } else 
  {
    print "\n\n";
    print colored("                       ", 'red on_green'), "\n";
    print colored("                       ", 'red on_green'), "\n";
    print colored("    WELCOME TO IPUB    ", 'red on_green'), "\n";
    print colored("                       ", 'red on_green'), "\n";
    print colored("                       ", 'red on_green'), "\n";
    print "\n\n";
  }
}


#################################################
#
# ticketing
#
#################################################

sub ticketing
{
  my $choice;

#  while (prompt "Must Enter PRR\/ODR\/IM ticket to continue\( q to exit\): ") 
  while (prompt colored("Must Enter PRR\/ODR\/IM ticket to continue\( q to exit\):", 'white on_blue')," ") 
  {
    $choice=$_;
    chomp($choice);
    exit if ($choice eq 'q');
    #last if ( $choice ne "");
    if ( $choice =~ /^[a-zA-Z0-9-]+$/ )
    {
      last;
    }
    else
    {
      print "\n ...... Ticket wrong format ......\n\n";
    }

  }

  print "\n\n You entered: $choice \n\n";
  $TKTNUM = $choice;
}


#################################################
#
# email
#
#################################################

sub email
{
  my $choice;

#  while (prompt "Must Enter email to continue\( q to exit\): ")
  while (prompt colored("Must Enter email to continue\( q to exit\):", 'white on_blue')," ")
  {
    $choice=$_;
    chomp($choice);
    exit if ($choice eq 'q');
    if ( $choice =~ /^[a-zA-Z0-9][a-zA-Z0-9.]+\@[a-zA-Z0-9.-]+$/ )
    {
      last;
    }
    else
    {
      print "\n ...... Email wrong format ......\n\n";
    }
  }

  print "\n\n You entered: $choice \n\n";

  $EMAIL = $choice;
}


#################################################
#
# exit
#
#################################################

sub exit_lg
{
  my $choice;
  my $txtfile;
  my $txtfile1;
  my $pdffile;
  my $pdffile1;

  if ( $DSTR eq "NO" )
  {
    print "\n\nBye !!!\n\n";
  }
  else
  {
   if  ( $ifUpgrade eq "YES" )
   {
    my $gstringrept = join " ","$GENREPTBIN","$TKTNUM","$EMAIL","$DSTR";
    $txtfile = `$gstringrept`;
    chomp $txtfile;
    if ( $txtfile ne "NOLOG" )
    {
       my $gstringpdf = join " ","$GENPDFBIN","$txtfile";
       $pdffile = `$gstringpdf`;
       
       while (prompt colored("Do you want to email the upgrade report \(y\|n\)\?", 'white on_blue')," ")
       {
         $choice=$_;
         chomp($choice);
         exit if ($choice eq 'q');
         if ( $choice =~ /^[yY]/ )
         {
           my $emailstring = "$EMREPTBIN $EMAIL $pdffile >/dev/null 2>&1";
           system("$emailstring");
           print "\n\nEmail sent to $EMAIL\n\n"
         }
         else
         {
           print "\n\nBye\n\n"
         }
         last;
       }
     }
   }

   ##########################################################################################


   if  ( $ifPatch eq "YES" )
   {
    my $gpatchrept = join " ","$GENPATCHREPTBIN","$TKTNUM","$EMAIL","$DSTR";
    my $gpatchrept1 = join " ","$GENPATCHREPT1BIN","$TKTNUM","$EMAIL","$DSTR";
    $txtfile = `$gpatchrept`;
    chomp $txtfile;
    $txtfile1 = `$gpatchrept1`;
    chomp $txtfile1;
    if ( $txtfile ne "NOLOG" )
    {
       my $gpatchpdf = join " ","$GENPDFBIN","$txtfile";
       $pdffile = `$gpatchpdf`;
       if ( $txtfile1 ne "NOLOG" ) {
         my $gpatchpdf1 = join " ","$GENPDFBIN","$txtfile1";
         $pdffile1 = `$gpatchpdf1`;
       }
       while (prompt colored("Do you want to email the patching and post-patching report \(y\|n\)\?", 'white on_blue')," ")
       {
         $choice=$_;
         chomp($choice);
         exit if ($choice eq 'q');
         if ( $choice =~ /^[yY]/ )
         {
           my $emailstring = "$EMPAREPTBIN $EMAIL $pdffile >/dev/null 2>&1";
           system("$emailstring");
           
           if ( $txtfile1 ne "NOLOG" ) {
              #my $emailstring1 = "$EMPAREPT1BIN $EMAIL $pdffile1 >/dev/null 2>&1";
              #text file for more clarity
              my $emailstring1 = "$EMPAREPT1BIN $EMAIL $txtfile1 >/dev/null 2>&1";

              system("$emailstring1");
           }

           print "\n\nEmail sent to $EMAIL\n\n"
         }
         else
         {
           print "\n\nBye\n\n"
         }
         last;
       }
     }
   }

   ##########################################################################################

  }

  exit;
}


#################################################
#
# Choice logic
#
#################################################

sub dispatch
{
 display_menu();

# while (prompt "Enter choice: ") {
 while (prompt colored("Enter choice:", 'white on_blue')," ") 
 {
   my $choice =$_;
   if ($choice eq 'q')
   {
     &exit_lg();
   }
   else
   {
     defined $choice or $choice = 'm';
     eval {$ops->{$choice}->()}; 
     display_menu();
   }
 }
} 


#################################################
#
# Inventory
#
#################################################

sub inventory_rl
{
    print "\n\n";
    print colored("                                           ", 'white on_blue'), "\n";
    print colored("   Entering RED HAT SATELLITE INVENTORY    ", 'white on_blue'), "\n";
    print colored("                                           ", 'white on_blue'), "\n";
    print "\n";
    print "     ", colored("u", 'white on_blue'), " - Page UP     ","\n";
    print "\n";
    print "     ", colored("d", 'white on_blue'), " - Page DOWN     ","\n";
    print "\n";
    print "     ", colored("t", 'white on_blue'), " - Top of the list     ","\n";
    print "\n";
    print "     ", colored("h", 'white on_blue'), " - Sort by host name     ","\n";
    print "\n";
    print "     ", colored("v", 'white on_blue'), " - Sort by OS Release     ","\n";
    print "\n";
    print "     ", colored("q", 'white on_blue'), " - Quit from the list     ","\n";
    print "\n";

    prompt colored("Type y to enter the inventory:", 'white on_blue'," ");

    my $ifEnter=$_;
    chomp($ifEnter);

    if ( $ifEnter =~ /^[yY]/ )
    {
         if ( -s "$RAWHOSTS" )
         {
            system("$PROCINVBIN $RAWHOSTS");
         }
    }

    dispatch();
}

#################################################
# patch
#################################################

sub patch_rl
{
 my @targets;
 my $randomstring = &getrndstr();
 my $patchtask = "$PATCHDIR"."$randomstring";
 my $hla = "$patchtask"."/"."$randomstring"."-hla.txt";
 my $hla1 = "$patchtask"."/"."$randomstring"."-hla1.txt";
 my $hla1a = "$patchtask"."/"."$randomstring"."-hla1a.txt";
 my $hla1a1 = "$patchtask"."/"."$randomstring"."-hla1a1.txt";
 my $hla1a1dis = "$patchtask"."/"."$randomstring"."-hla1a1dis.txt";
 my $hla1a2 = "$patchtask"."/"."$randomstring"."-hla1a2.txt";
 my $hla1a1a = "$patchtask"."/"."$randomstring"."-hla1a1a.txt";
 my $hla1a1a1 = "$patchtask"."/"."$randomstring"."-hla1a1a1.txt";
 my $hla1a1a2 = "$patchtask"."/"."$randomstring"."-hla1a1a2.txt";
 my $hla1a1a3 = "$patchtask"."/"."$randomstring"."-hla1a1a3.txt";
 my $hla1a1a4 = "$patchtask"."/"."$randomstring"."-hla1a1a4.txt";
 my $hla1a1b = "$patchtask"."/"."$randomstring"."-hla1a1b.txt";
 my $hla1a1adis = "$patchtask"."/"."$randomstring"."-hla1a1adis.txt";
 my $hla1a3 = "$patchtask"."/"."$randomstring"."-hla1a3.txt";
 my $hla1a4 = "$patchtask"."/"."$randomstring"."-hla1a4.txt";
 my $hla1b = "$patchtask"."/"."$randomstring"."-hla1b.txt";
 my $hla1c = "$patchtask"."/"."$randomstring"."-hla1c.txt";
 my $hla2 = "$patchtask"."/"."$randomstring"."-hla2.txt";
 my $hla3 = "$patchtask"."/"."$randomstring"."-hla3.txt";
 my $patchlog = "$patchtask"."/"."$randomstring"."-plog.txt";
 my $chk1a = "$patchtask"."/"."$randomstring";
 my $logfh;

 unlink $hla;
 unlink $hla1;
 unlink $hla2;
 unlink $hla3;
 #unlink $patchlog;

 mkdir $patchtask, 0755;

 $ifPatch = "YES";

 open($logfh, '>>', $patchlog) or die "Could not open file  $patchlog: $!";

 my $hstlist = &processinput;

 if ($hstlist =~ /[a-zA-Z]/)
 {
   print "\n\n...... Checking inventory for below hosts ......\n\n";
   print $logfh "\n\n...... Checking inventory for below hosts ......\n\n";

   @targets= split /\s+/, $hstlist;

   print "$hstlist\n\n";
   print $logfh "$hstlist\n\n";
 }
 else
 {
   @targets = &processfile;

   print "\n\n####### Checking inventory for below hosts #######\n\n";
   print $logfh "\n\n####### Checking inventory for below hosts #######\n\n";

   print  "@targets\n\n";
   print  $logfh "@targets\n\n";
 }

 open my $fh, ">", "$hla" or die $!;
 print $fh "$_\n" for @targets;

 close $fh;

 foreach my $target (@targets)
 {
    my $prepstring = join " ","$PREPATSORTBIN","$target","$hla1","$hla2","$hla3";
    system("$prepstring");
 }
 if ( -s "$hla3" )
 {
    print "\n\n...... Below hosts are not valid host managed by satellite ......\n\n";
    print $logfh "\n\n...... Below hosts are not valid host managed by satellite ......\n\n";

    open (FILE, '<', "$hla3") or die $!;
    open (LFILE, '<', "$hla3") or die $!;

    print <FILE>;
    print $logfh <LFILE>;

    close (FILE);
    close (LFILE);
 }
 if ( -s "$hla2" )
 {
    print "\n\n...... Below hosts need to be upgraded ......\n\n";
    print $logfh "\n\n...... Below hosts need to be upgraded ......\n\n";

    open (FILE, '<', "$hla2") or die $!;
    open (LFILE, '<', "$hla2") or die $!;

    print <FILE>;
    print $logfh <LFILE>;

    close (FILE);
    close (LFILE);
 }
 if ( -s "$hla1" )
 {
    print "\n\n...... Below hosts can be patched ......\n\n";
    print $logfh "\n\n...... Below hosts can be patched ......\n\n";

    open (FILE, '<', "$hla1") or die $!;
    open (LFILE, '<', "$hla1") or die $!;

    print <FILE>;
    print $logfh <LFILE>;

    close (FILE);
    close (LFILE);

    print "\n";
    print $logfh "\n";

    while (prompt colored("Must type y to proceed with the patching on above hosts\( q to exit\):", 'white on_blue')," ")
    {
      my $ifConf=$_;
      chomp($ifConf);
      exit if ($ifConf eq 'q');
      last if ( $ifConf =~ /^[yY]/ );
    }

    print "\n\n####### Sanity check on below hosts #######\n\n";

    system("$CHECKBOOTBIN $hla1 $chk1a");

    #sleep(3);

    system("$PROCESSBOOTBIN $patchtask $randomstring $hla1a $hla1b $hla1c");

    if ( -s "$hla1c" )
    {
      print "\n\n...... Below hosts are not reachable from ansible ......\n\n";
      print $logfh "\n\n...... Below hosts are not reachable from ansible ......\n\n";

      open (FILE, '<', "$hla1c") or die $!;
      open (LFILE, '<', "$hla1c") or die $!;

      print <FILE>;
      print $logfh <LFILE>;

      close (FILE);
      close (LFILE);
    }

    if ( -s "$hla1b" )
    {
      print "\n\n...... Below hosts can not be patched becasue boot size is too small ......\n\n";
      print $logfh "\n\n...... Below hosts can not be patched becasue boot size is too small ......\n\n";

      open (FILE, '<', "$hla1b") or die $!;
      open (LFILE, '<', "$hla1b") or die $!;

      print <FILE>;
      print $logfh <LFILE>;

      close (FILE);
      close (LFILE);
    }

    if ( -s "$hla1a" )
    {
      print "\n\n...... Below hosts passed the Sanity check ......\n\n";
      print $logfh "\n\n...... Below hosts passed the Sanity check ......\n\n";

      open (FILE, '<', "$hla1a") or die $!;
      open (LFILE, '<', "$hla1a") or die $!;

      print <FILE>;
      print $logfh <LFILE>;

      close (FILE);
      close (LFILE);

      print "\n";
      print $logfh "\n";

      while (prompt colored("Must type y to proceed with the patching on above hosts\( q to exit\):", 'white on_blue')," ")
      {
        my $ifConf=$_;
        chomp($ifConf);
        exit if ($ifConf eq 'q');
        last if ( $ifConf =~ /^[yY]/ );
      }

      print "\n\n...... Backing up system files and prepare environment for below hosts ......\n\n";
 
      system("$UPLOADPATCHBIN $hla1a");

      #sleep(3);

      system("$INSTALLIPUBCBIN $hla1a");

      #sleep(3);

      system("$PROCBKPENVBIN $hla1a $chk1a");

      #sleep(3);
   
      print "\n\n...... Syncing system configuraton back up files to NFS share for below hosts ......\n\n";

      system("$SYNCBKPBIN $hla1a");

      print "\n\n";

      prompt colored("Type y if its dry run \(not actually upgrade and reboot\):", 'white on_blue'," ");
      my $ifDry=$_;
      chomp($ifDry);
       
      system("$GETKERNELVERBIN $patchtask $randomstring $hla1a1 $hla1a2 $hla1a3 $hla1a4 $hla1a1dis");

      if ( -s "$hla1a3" )
      {
      print "\n\n...... Below hosts has issue, can not be patched, please investigate ......\n\n";
      print $logfh "\n\n...... Below hosts has issue, can not be patched, please investigate ......\n\n";

      open (FILE, '<', "$hla1a3") or die $!;
      open (LFILE, '<', "$hla1a3") or die $!;

      print <FILE>;
      print $logfh <LFILE>;

      close (FILE);
      close (LFILE);
      }

      if ( -s "$hla1a2" )
      {
      print "\n\n...... Below hosts can not be patched becasue var free space is too small ......\n\n";
      print $logfh "\n\n...... Below hosts can not be patched becasue var free space is too small ......\n\n";

      open (FILE, '<', "$hla1a2") or die $!;
      open (LFILE, '<', "$hla1a2") or die $!;

      print <FILE>;
      print $logfh <LFILE>;

      close (FILE);
      close (LFILE);
      }

      if ( -s "$hla1a4" )
      {
      print "\n\n...... Below hosts will not be patched as they alread been patched or nothing to patch ......\n\n";
      print $logfh "\n\n...... Below hosts will not be patched as they alread been patched or nothing to patch ......\n\n";

      open (FILE, '<', "$hla1a4") or die $!;
      open (LFILE, '<', "$hla1a4") or die $!;

      print <FILE>;
      print $logfh <LFILE>;

      close (FILE);
      close (LFILE);
      }

      #if ( -s "$hla1a1" )
      #{
      #print "\n\n...... Below hosts will be patched and rebooted......\n\n";
      #open (FILE, '<', "$hla1a1") or die $!;
      #print <FILE>;
      #close (FILE);
      #}
 
      #if ( -s "$hla1a1dis" )
      # {
      #print "\n\n...... Below hosts will not be patched to below kernel verions ......\n\n";
      #open (FILE, '<', "$hla1a1dis") or die $!;
      #print <FILE>;
      #close (FILE);
      #}

      if ( $ifDry =~ /^[yY]/ )
      {

         if ( -s "$hla1a1dis" )
         {
          print "\n\n...... Below hosts can be patched to below kernel verions ......\n\n";
          print $logfh "\n\n...... Below hosts can be patched to below kernel verions ......\n\n";

          open (FILE, '<', "$hla1a1dis") or die $!;
          open (LFILE, '<', "$hla1a1dis") or die $!;

          print <FILE>;
          print $logfh <LFILE>;

          close (FILE);
          close (LFILE);
         }
      }
      else
      {
         if ( -s "$hla1a1" )
         {
           print "\n\n...... Below hosts will be patched and rebooted ......\n\n";
           print $logfh "\n\n...... Below hosts will be patched and rebooted ......\n\n";

           open (FILE, '<', "$hla1a1") or die $!;
           open (LFILE, '<', "$hla1a1") or die $!;

           print <FILE>;
           print $logfh <LFILE>;

           close (FILE);
           close (LFILE);

           if ( -s "$hla1a1dis" )
           {
             print "\n\n...... New kernel verions after the patching and reboot......\n\n";
             print $logfh "\n\n...... New kernel verions after the patching and reboot......\n\n";

             open (FILE, '<', "$hla1a1dis") or die $!;
             open (LFILE, '<', "$hla1a1dis") or die $!;

             print <FILE>;
             print $logfh <LFILE>;

             close (FILE);
             close (LFILE);

             print "\n\n";
             print $logfh "\n\n";
           }

           while (prompt colored("Must type y to proceed with the patch/reboot on above hosts\( q to exit\):", 'white on_blue')," ")
           {
             my $ifConf=$_;
             chomp($ifConf);
             exit if ($ifConf eq 'q');
             last if ( $ifConf =~ /^[yY]/ );
           }

           ###############################################################

           print "\n\n...... Patching and rebooting below hosts, please be patient ......\n\n";
           
           system("$UPGRADEWREBIN $hla1a1 $chk1a");

           #sleep(3);

           system("$UPGRADEWREFINBIN $hla1a1 $chk1a");

           #sleep(3);

           system("$CHKKERNELPOSTBIN $hla1a1 $chk1a");

           #sleep(3);

           system("$COMPAREKERVERPOSTBIN $patchtask $randomstring $hla1a1a $hla1a1adis");

           #sleep(3);

           system("$GETFAILEDLISTBIN $hla1a1 $hla1a1a $hla1a1b");

           if ( -s "$hla1a1a" )
           {
             print "\n\n...... Below hosts have been successfully patched and rebooted ......\n\n";
             print $logfh "\n\n...... Below hosts have been successfully patched and rebooted ......\n\n";

             open (FILE, '<', "$hla1a1a") or die $!;
             open (LFILE, '<', "$hla1a1a") or die $!;

             print <FILE>;
             print $logfh <LFILE>;

             close (FILE);
             close (LFILE);

             if ( -s "$hla1a1dis" )
             {
               print "\n\n...... Current kernel verions ......\n\n";
               print $logfh "\n\n...... Current kernel verions ......\n\n";

               open (FILE, '<', "$hla1a1adis") or die $!;
               open (LFILE, '<', "$hla1a1adis") or die $!;

               print <FILE>;
               print $logfh <LFILE>;

               close (FILE);
               close (LFILE);

               print "\n\n";
               print $logfh "\n\n";
             }
           }

           if ( -s "$hla1a1b" )
           {
             print "\n\n...... Below hosts failed or timed out, please investigate ......\n\n";
             print $logfh "\n\n...... Below hosts failed or timed out, please investigate ......\n\n";

             open (FILE, '<', "$hla1a1b") or die $!;
             open (LFILE, '<', "$hla1a1b") or die $!;

             print <FILE>;
             print $logfh <LFILE>;

             close (FILE);
             close (LFILE);
           }

           if ( -s "$hla1a1a" )
           {
              print "\n\n...... Post patching check and back up for below hosts after patching......\n\n";

              system("$PROCBKPENVPOSTBIN $hla1a1a $chk1a");

              #sleep(3);

              print "\n\n...... Syncing system configuraton back up files to NFS share for below hosts ......\n\n";

              system("$SYNCBKPBIN $hla1a1a");

              print "\n\n...... Applying Exelon security baseline after patching ......\n\n";

              system("$ENFORCESBLPLY6 $hla1a1a $chk1a");

              #sleep 3;

              system("$ENFORCESBLPLY7 $hla1a1a $chk1a");
     
              #sleep 3;

              system("$CHKSBLSTATBIN $hla1a1a $chk1a");

              system("$PROCESSSBLBIN $patchtask $randomstring $hla1a1a1 $hla1a1a2");

              if ( -s "$hla1a1a1" )
              {
                print "\n\n...... Below hosts have been successfully applied Exelon security baseline ......\n\n";
                print $logfh "\n\n...... Below hosts have been successfully applied Exelon security baseline ......\n\n";

                open (FILE, '<', "$hla1a1a1") or die $!;
                open (LFILE, '<', "$hla1a1a1") or die $!;

                print <FILE>;
                print $logfh <LFILE>;

                close (FILE);
                close (LFILE);
              }

              if ( -s "$hla1a1a2" )
              {
                print "\n\n...... Failed to apply Exelon security baseline on below hosts ......\n\n";
                print $logfh "\n\n...... Failed to apply Exelon security baseline on below hosts ......\n\n";

                open (FILE, '<', "$hla1a1a2") or die $!;
                open (LFILE, '<', "$hla1a1a2") or die $!;

                print <FILE>;
                print $logfh <LFILE>;

                close (FILE);
                close (LFILE);
              }

         #######################################################################
         #######################################################################

              print "\n\n...... Sync root password after patching on below hosts ......\n\n";

              system("$ENFORCEROOT $hla1a1a $chk1a");

              #sleep 3;

              #system("$CHKROOTBIN $hla1a1a $chk1a");

              #sleep 3;

              #system("$PROCESSROOTBIN $patchtask $randomstring $hla1a1a3 $hla1a1a4");

              #if ( -s "$hla1a1a3" )
              #{
              #  print "\n\n...... Below hosts have been successfully sync-ed root password ......\n\n";
              #  open (FILE, '<', "$hla1a1a3") or die $!;
              #  print <FILE>;
              #  close (FILE);
              #  print "\n\n";
              #}

              #if ( -s "$hla1a1a4" )
              #{
              #  print "\n\n...... Failed to sync root password on below hosts ......\n\n";
              #  open (FILE, '<', "$hla1a1a4") or die $!;
              #  print <FILE>;
              #  close (FILE);
              #  print "\n\n";
              #}

         ########################################################################
         #######################################################################

           }

        ###############################################################

         }
      }
    }
  }
 close ($logfh);
}

#################################################
# build
#################################################

sub build_rl
{
print "\n\n...... this is under construction ......\n\n";
dispatch();
}

#################################################
# upgrade
#################################################

sub upgrade_rl 
{
 $ifUpgrade = "YES";

 #prompt "Enter host name to upgrade: ";
 prompt colored("Enter host name to upgrade:", 'white on_blue')," ";

 my $hostn = $_;

 $hostn=~s/^\s+//;
 $hostn=~s/\s+$//;
 $hostn =~ tr/A-Z/a-z/; 

 my $getmacstring = join " ",$SATHSTVRFYBIN,$hostn,"macaddress"; 
 my $getrelstring = join " ",$SATHSTVRFYBIN,$hostn,"release"; 
 my $hststat = `$getmacstring`;
 my $hstrel = `$getrelstring`;

 my $fh;

 if ($hststat =~ /INVALID/)
 {
   print "\n\n ...... Please enter an valid host ...... \n\n\n";
   dispatch();
 }
 elsif ($hststat =~ /INCOMPLETE/)
 {
   print "\n\n ...... You entered incomplete host name ......\n\n";
   dispatch();
 }
 elsif ( &readmacaddress($hststat) eq "macok" )
 {
   while (prompt colored("Must type y to proceed with the upgrade\( q to exit\):", 'white on_blue')," ")
   {
      my $ifConf=$_;
      chomp($ifConf);
      exit if ($ifConf eq 'q');
      last if ( $ifConf =~ /^[yY]/ );
   }
  
   my $rmtstring;
   my $rmtstrings;

   my $randomstring = &getrndstr();

   my $prelog = "$BASEDIR"."$hostn"."-"."$randomstring"."-pre";
   my $aftlog = "$BASEDIR"."$hostn"."-"."$randomstring"."-aft";
   my $loclog = "$BASEDIR"."$hostn"."-"."$randomstring"."-loc";
   my $sbllog = "$BASEDIR"."$hostn"."-"."$randomstring"."-sbl";
   my $sblcon = "$BASEDIR"."$hostn"."-"."$randomstring"."-sco";
   my $synlog = "$BASEDIR"."$hostn"."-"."$randomstring"."-syn";
   my $syncon = "$BASEDIR"."$hostn"."-"."$randomstring"."-syo";
   my $runhost = "$BASEDIR"."$hostn"."-"."$randomstring"."-inv";

   open($fh, '>>', $loclog) or die "Could not open file  $loclog: $!";;

   print "\n\n####### Sanity check for $hostn #######\n\n";
   print $fh "\n\n####### Sanity check for $hostn #######\n\n";

   my $getfqdn = join " ",$SATHSTVRFYBIN,$hostn,"fqdn";
   my $fqdn = `$getfqdn`;
   my @fqdnarr = split /\./, $fqdn;
   splice @fqdnarr, 0, 1;
   my $dmname = join "\.",@fqdnarr;
   
   open(my $invhst, '>', $runhost);
   print $invhst "$hostn";
   close $invhst;

   system("$RMTVRFYBIN $runhost $prelog &");   
   sleep(5);
   my $prestat = &preupchk($prelog);

   my $aftstat;
   my $sblstat;
   my $synstat;
   my $osrels;
   my $upgtrels;

   if ( $prestat eq "NORECH" )
   {
     print "\n\n ...... $hostn is not reachable......\n\n";
     print $fh "\n\n ...... $hostn is not reachable......\n\n";

     prompt colored("Do you want to update satellite profile for $hostn \(y\|n\):", 'white on_blue')," ";
     if ( $_ =~ /^[yY]/ ) 
     {
       $osrels = &readrelease($hstrel);
       if ( $osrels eq "6" || $osrels eq "7" )
       {
         if ( $osrels eq "6" )
         {
           $upgtrels = "6.10";
         }
         else
         {
           $upgtrels = "7.5";
         }
       
         chomp($hostn);
         chomp($dmname);
         chomp($upgtrels);
         chomp($hststat);

         $rmtstrings = "ssh satlnxbup-001 \"exlib-upgrade67s.pl -h $hostn -d $dmname -r $upgtrels -m $hststat\" 2>/dev/null | tee -a $loclog";
         system("$rmtstrings");
         dispatch();
       }
       else
       {
         dispatch(); 
       }
     }
   }
   elsif ( $prestat eq "SPSML" )
   {
     print "\n\n ...... $hostn boot file system size is too small ......\n\n";
     print $fh "\n\n ...... $hostn boot file system size is too small ......\n\n";
     dispatch();
   }
   elsif ( $prestat eq "SPOK" )
   { 
     $osrels = &readrelease($hstrel);
     if ( $osrels eq "6" || $osrels eq "7" )
     {
       if ( $osrels eq "6" )
       {
         $upgtrels = "6.10";
       }
       else
       {
         $upgtrels = "7.5";
       }
      
       chomp($hostn); 
       chomp($dmname); 
       chomp($upgtrels); 
       chomp($hststat); 
               
       $rmtstring = "ssh satlnxbup-001 \"exlib-upgrade67.pl -h $hostn -d $dmname -r $upgtrels -m $hststat\" 2>/dev/null | tee -a $loclog";
       #print "$rmtstring\n";

       print "\n\n####### Upgrading $hostn #######\n\n";
       print $fh "\n\n####### Upgrading $hostn #######\n\n";
       system("$rmtstring");

       system("$RMTCONFBIN $runhost $aftlog");
       sleep(5);
       $aftstat = &aftupchk($aftlog);
       
       if ( $aftstat eq "NORECH" )
       {
         print "\n\n ...... $hostn is not reachable ......\n\n";
         print $fh "\n\n ...... $hostn is not reachable ......\n\n";
         dispatch();
       }
       elsif ( $aftstat eq "FAILED" )
       {
         print "\n\n ...... Upgrade on $hostn -- $aftstat ......\n\n";
         print $fh "\n\n ...... Upgrade on $hostn -- $aftstat ......\n\n";
         dispatch();
       }
       elsif ( $aftstat =~ /(\d\.\d\d*)/ )
       {
         print "\n\n ...... $hostn successfully upgraded to $aftstat ......\n\n";
         print $fh "\n\n ...... $hostn successfully upgraded to $aftstat ......\n\n";
     
         print "\n\n###### Enforcing Exelon Security Baseline ######\n\n"; 
         print $fh "\n\n###### Enforcing Exelon Security Baseline ######\n\n"; 

         &enforcesbl($hostn,$osrels,$sbllog);

         system("$SBLCONFBIN $runhost $sblcon");
         sleep(5);
         $sblstat = &sblchk($sblcon);

         if ( $sblstat eq "NORECH" )
         {
           print "\n\n ...... Can not verify becasue $hostn is not reachable ......\n\n";
           print $fh "\n\n ...... Can not verify becasue $hostn is not reachable ......\n\n";
           dispatch();
         }
         elsif ( $sblstat eq "FAILED" )
         {
           print "\n\n ...... Enforcing Security baseline on $hostn -- $sblstat ......\n\n";
           print $fh "\n\n ...... Enforcing Security baseline on $hostn -- $sblstat ......\n\n";
           dispatch();
         }
         elsif ( $sblstat eq "SUCCESS" )           
         {
           print "\n\n ...... Enforcing Security baseline on $hostn -- $sblstat ......\n\n";
           print $fh "\n\n ...... Enforcing Security baseline on $hostn -- $sblstat ......\n\n";

           print "\n\n####### Enforcing root password for $hostn #######\n\n"; 
           print $fh "\n\n####### Enforcing root password for $hostn #######\n\n"; 

           &enforcesyn($hostn,$synlog);

           system("$SYNCONFBIN $runhost $syncon");
           sleep(5);
           $synstat = &synchk($syncon,$synlog); 

           if ( $sblstat eq "NORECH" )
           {
              print "\n\n ...... Can not verify becasue $hostn is not reachable ......\n\n";
              print $fh "\n\n ...... Can not verify becasue $hostn is not reachable ......\n\n";
              dispatch();
           }
           elsif ( $sblstat eq "FAILED" )
           {
              print "\n\n ...... Enforcing root password on $hostn -- $sblstat ......\n\n";
              print $fh "\n\n ...... Enforcing root password on $hostn -- $sblstat ......\n\n";
              dispatch();
           }
           elsif ( $sblstat eq "NONEED" )
           {
              print "\n\n ...... root password is curremt on $hostn ......\n\n";
              print $fh "\n\n ...... root password is curremt on $hostn ......\n\n";
              dispatch();
           }
           elsif ( $sblstat eq "SUCCESS" )
           {
              print "\n\n ...... Enforcing root password on $hostn -- $sblstat ......\n\n";
              print $fh "\n\n ...... Enforcing root password on $hostn -- $sblstat ......\n\n";
              dispatch();
           }
           else
           {
              print "\n\n\n";
              dispatch();     
           }
         }
         else
         {
           print "\n\n\n";
           dispatch();
         }
       }
       else
       {
         print "\n\n\n";
         dispatch();
       }
     }
     elsif ( &readrelease($hstrel) eq "5" )
     {
       print "\n\n ...... RHEL 5 host can not be upgraded ......\n\n";
       dispatch();
     }
     else
     {
       print "\n\n\n";
       dispatch();
     }
  }
  else
  {
    print "\n\n\n";
    dispatch();
  }
 }
 else
 {
   print "\n\n\n";
   dispatch();
 }
 close $fh;
}

#################################################
# Main
#################################################

sub satmlg
{
 &authusr();
 &ticketing();
 &email();
 &dispatch();
}

=head1 NAME

    ipub;

=head1 DESCRIPTION

   Menu driven automation tool to 
    -  upgrade
    -  patch
    -  build
    -  check inventory

   This apply to all Red Hat Satellite managed Linux hosts
   This do not apply to Linux hosts in Azure or other public cloud

=head2 

=over 12

=item C<Step 1>

ssh into ansible-omf-01v from admin server

=item C<Step 2>

Run ipub after logged in

=item C<Step 3>

Enter Exelon/vendor ticket number 

=item C<Step 4>

Enter Email address 

=item C<Step 5>

Choose i to check satellite inventory

Choose p to patch one/multiple servers currently (for RHEL 6.10 and 7.6 and up)

choose u to upgrade one server (for RHEL lower than 6.10 and 7.6)

choose b to build (under construction)

=item C<Step 6>

Quit - type q to exit from the menu

=back

=head1 MANUALS

   For detailed instruction cut and paste below link carefully below documents

     -  Inventory - http://exliport.exelonds.com:32768/ipub-p.pdf

     -  Patch - http://exliport.exelonds.com:32768/ipub-p.pdf

     -  Patch Agent - http://exliport.exelonds.com:32768/ipubc.pdf

     -  Upgrade - http://exliport.exelonds.com:32768/ipub-u.pdf

     -  Build - under construction


=head1 AUTHORS

Run Zhang @ July 2019


=cut

1
