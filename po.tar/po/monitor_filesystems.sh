#!/bin/ksh 
################################################################################
#                                                                              #
# monitor_filesystems.sh                                                       #
#                                                                              #
# This script monitors filesystem usage.  Email is sent to various groups      #
# whenever the $mailTH threshold is reached.  Once filesystem usage reaches    #
# $pageTH, pages are sent to the groups.                                       #
#                                                                              #
################################################################################

################################################################################
# Change Log                                                                   #
################################################################################
#                                                                              #
# 2010.10.17:  - Single alert for NAS volume                                   #
# 2010.10.17:  - Page T2 Unix insead of unixadmin                              #
# 2010.10.17:  - no major alert for 90-94%                                     #
# 2010.06.02:  - Added global exception for CIFS filesystems                   #
# 2010.01.05:  - Code added to accomodate Linux (TAIL variable mainly)         #
# 2009.08.03:  - Modified OVOgrp variable to have quotes and {}                #
# 2009.05.19:  - Modified code to read a distributed exceptions file           #
#              - Excluded mailout code if a unixadmin FS                       #
# 2008.03.17:  - Added logic for /CERdw to go to #CER Integration Team         #
# 2008.01.04:  - Added logic for CCG vs CEG filesystems owned by applmgr       #
#              - Fixed the check_if_running logic                              #
# 2007.11.14:  - Removed emailing and paging to DBA's.                         #
#              - Took out the paging modules since we have the NOC page        #
#              - Removed previous change log info, see archived scripts        #
# 2015.01.25:  - Seperate local from NFS file systems                          #
#			   - Ensure one monitoring instance run                            #
#			   - Fix cifs checking bug                                         #
#			   - Lock fie implemented to prevent multiple emails when NFS hang #
#              - Automatically killing hanging df process after timeout        #
#              - Unix team paged only for root/adm/bin owned  FS               #
#              - Inform NOC to page appropriate application team               # 
#                if FS owner's administration group can not be determined      #
#              - NFS owner determined based real file content owner and        #
#                inform NOC the user list                                      #
# 2015.02.06:  - fix reporting NFS subdirectory by unknown users               #
# 2015.05.28:  - fix hostname is in FQDN issue                                 #
#              - Warn based on NAS volume instead of MP                        #
#              - Mechanism to report all hosts mounted to NAS volume           #
#              - Exclude all zone related fs (swapfs etc)                      #
# 2015.09.17   - Clear zstat file                                              #
# 2016.06.27   - exclude all auto homes and non local mounted home             #
#                                                                              #
################################################################################

################################################################################
# Information about this script                                                #
################################################################################

#########################
#  Files used / format  #
#########################
# monitor_filesystesm.sh.all, and all.prev
# $fsPctUsed $fsAvail $NFSorNAS $fsMount
#
# monitor_filesystems.sh.warn, warn.prev and warn.changes
# $fsname $fsNFS at ${fspct}%
#
# monitor_filesystems.sh.warn.delta
# $fsrec with ${fsfree}k free owner=$fsowner pageable=$sendpage
#
# monitor_filesystems.sh.cleared.changes

################################################################################
# Set up environment variables                                                 #
################################################################################

tempdir=/var/tmp                                # Location for temporary files for file system info
scrname=`basename $0`                           # Script name
server=`uname -n | cut -f1 -d. | tr '[A-Z]' '[a-z]'`                               # Server name where script is running
ScriptLoc=/etc                                  # Location of mailout & pageout scripts
DBAPAGEROUTE=/etc/dbapage.route                 # Location of email and page routing information
ServerData=/opt/sysadmin/etc/active.servers.all # Location of the Server Inventory DB data
ExceptFileLoc=/etc/filesystem_exceptions        # Set up the location of the exceptions file
DATE=`date '+%m/%d/%y %H:%M:%S'`
RESPERD=10
LOCKFILE=$tempdir/$scrname.lock
NFSLOCKFILE=$tempdir/$scrname.nfs.lock
NASDATALOC=/etc/nas_volume_list
ZSLOG="/var/adm/exacct/zstat-process"
ZSLOGTHRESH=5
SVCADMBIN="/usr/sbin/svcadm"

#################################################
### Threshold 
#################################################

mailTH=90 # email warning threshold (OVO - Major Alarm)
pageTH=95 # page critical threshold (OVO - Critical Alarm)

oraclelog=$tempdir/$scrname.logoracle
if [ -f $oraclelog ]
  then :
  else touch $oraclelog
fi

alertlog=$tempdir/$scrname.logalerts
if [ -f $alertlog ]
  then :
  else touch $alertlog
fi

# HP-UX Specific        
if uname -s | grep -i "^HP" > /dev/null 2>&1
then 
   OSTYPE="HP"; export OSTYPE
   BDF="/usr/bin/bdf"
   LBDF="/usr/bin/bdf -l"
   NBDF="/usr/bin/bdf -t nfs"
   TAIL="/usr/bin/tail"
# Solaris Specific      
elif uname -s | grep -i "^SUN" > /dev/null 2>&1
then
   OSTYPE="SUN"; export OSTYPE
   BDF="/usr/bin/df -b -k"
   LBDF="/usr/bin/df -b -k -l"
   NBDF="/usr/bin/df -b -k -F nfs"
   TAIL="/usr/bin/tail"

   # Add /usr/xpg4/bin to beginning of path
   case $PATH in
      /usr/xpg4/bin*)         continue ;;
      '')                     continue ;;
      :*)                     PATH=:/usr/xpg4/bin$PATH ;;
      *)                      PATH=/usr/xpg4/bin:$PATH ;;
   esac
   echo PATH is $PATH

   # Make sure /usr/sbin is in PATH
   case $PATH in
      */usr/sbin*)            continue ;;
      '')                     continue ;;
      *:)                     PATH=${PATH}/usr/sbin ;;
      *)                      PATH=${PATH}:/usr/sbin ;;
   esac

   export PATH

############################
# Linux Specific        
###########################

elif uname -s | grep -i "^LINUX" > /dev/null 2>&1
then
   OSTYPE="LINUX"; export OSTYPE
   BDF="/bin/df -k"
   LBDF="/bin/df -k -l"
   NBDF="/bin/df -k -t nfs"
   TAIL="/usr/bin/tail -n"
fi

#########################
# Set up Server VARs    #
#########################

if grep "^$server" $DBAPAGEROUTE | grep -q ":email:"
then 
   sendpage=N
fi

ServerData=/opt/sysadmin/etc/active.servers.all # Location of the Server Inventory DB data
ServerRecord=`grep "^$server" $ServerData` 
ServerDataUSE=`echo $ServerRecord | awk '{print $4}'`
ServerDataCBP=`echo $ServerRecord | awk '{print $8}'`

#########################
# Exclude FS from going #
# into *warn fles       #
#########################

## Excluing zone OS defualt file systems

EXCLUDEFS="/net/admin-omf1|/StagedStorageUnit/Drive|/cdrom|/devices|/system/contract|/proc|/etc/mnttab|/etc/svc/volatile|/system/object|/etc/dfs/sharetab|/dev/fd|/var/run|/dev/vx/dmp|/dev/vx/rdmp"

#########################
check_if_running ()     #
#########################

{
if [ -e ${LOCKFILE} ] && kill -0 `cat ${LOCKFILE}` 
then
#echo  "The file system monitor did not finish on time, Please investigate." | mailx -s $server UNIXEngineering@constellation.com
exit
fi
trap "rm -f ${LOCKFILE}; exit" INT TERM EXIT
echo $$ > ${LOCKFILE}
}

###################################
# MAIN Script
##################################

check_if_running

#########################
### Initialization
#########################
mv $tempdir/$scrname.warn $tempdir/$scrname.warn.prev > /dev/null 2>&1 
touch $tempdir/$scrname.warn > /dev/null 2>&1 
mv $tempdir/$scrname.all $tempdir/$scrname.all.prev > /dev/null 2>&1 
touch $tempdir/$scrname.all > /dev/null 2>&1

#######################################
### Process nas volume information
#######################################

[ -f $tempdir/$scrname.nfsdev.$server ] && rm -f $tempdir/$scrname.nfsdev.$server > /dev/null 2>&1 
[ -f $tempdir/$scrname.nasvolumes ] && rm -f $tempdir/$scrname.nasvolumes > /dev/null 2>&1 
[ -s $NASDATALOC ] && cat $NASDATALOC | grep $server, | awk  -F";" '!/^#/ && $1 ~ /^[A-Za-z]+.*:\/[A-Za-z]+.*/ && $2 ~ /^[A-Za-z]+.*,/' | sed 's/,$//' > $tempdir/$scrname.nasvolumes

SplitLines=N
$LBDF | $TAIL +2 | while read bdfrec
do
    if [ "$SplitLines" = "N" ]
    then
        fsName=`echo "$bdfrec" | awk '{print $1}'`
        if echo "$fsName" | grep -q ":"
        then
            NASorNFS=Y
        else
            NASorNFS=N
        fi
        fsKbytes=`echo "$bdfrec" | awk '{print $2}'`
        if [ "$fsKbytes" = "" ]
        then
            SplitLines=Y
	    continue
	fi
        fsKbytes=`echo "$bdfrec" | awk '{print $2}'`
        fsUsed=`echo "$bdfrec" | awk '{print $3}'`
        fsAvail=`echo "$bdfrec" | awk '{print $4}'`
        fsPctUsed=`echo "$bdfrec" | awk '{print $5}'|sed "s/%//g"`
        fsMount=`echo "$bdfrec" | awk '{print $6}'`
    else
        SplitLines=N
        fsKbytes=`echo "$bdfrec" | awk '{print $1}'`
        fsUsed=`echo "$bdfrec" | awk '{print $2}'`
        fsAvail=`echo "$bdfrec" | awk '{print $3}'`
        fsPctUsed=`echo "$bdfrec" | awk '{print $4}'|sed "s/%//g"`
        fsMount=`echo "$bdfrec" | awk '{print $5}'`
    fi
     
    if ! echo $fsMount | egrep '^/home/[A-Za-z]+[-A-Za-z0-9_]*$'
	then
      echo "$fsPctUsed $fsAvail $NASorNFS $fsMount" >> $tempdir/$scrname.all
    else
	  if echo $fsName | egrep '^/dev/|^[a-zA-Z]+[-a-zA-Z0-9_]*/'  
	  then
		echo "$fsPctUsed $fsAvail $NASorNFS $fsMount" >> $tempdir/$scrname.all
      fi
	fi

done

$NBDF > $tempdir/$scrname.nfs.tmp 2>/dev/null  &
sleep $RESPERD
if kill -0 $! 2>/dev/null
then
kill -9 $!
if ! [ -e $NFSLOCKFILE ]
then
touch $NFSLOCKFILE
#echo  "File system monitor could not complete becasue of nfs issue, Please investigate." | mailx -s $server UNIXEngineering@constellation.com
fi
else
[ -e $NFSLOCKFILE ] && rm -f $NFSLOCKFILE
if [ -s "$tempdir/$scrname.nfs.tmp" ]
then
SplitLines=N  
cat $tempdir/$scrname.nfs.tmp | $TAIL +2 | while read bdfrec
do
    NASorNFS=Y
    if [ "$SplitLines" = "N" ]
    then
        fsName=`echo "$bdfrec" | awk '{print $1}'`
		if echo "$fsName" | grep -q ":"
		then
		  printf "$fsName,$server" >> $tempdir/$scrname.nfsdev.$server
		fi 
        fsKbytes=`echo "$bdfrec" | awk '{print $2}'`
        if [ "$fsKbytes" = "" ]
        then
            SplitLines=Y
	    continue
	    fi
        fsKbytes=`echo "$bdfrec" | awk '{print $2}'`
        fsUsed=`echo "$bdfrec" | awk '{print $3}'`
        fsAvail=`echo "$bdfrec" | awk '{print $4}'`
        fsPctUsed=`echo "$bdfrec" | awk '{print $5}'|sed "s/%//g"`
        fsMount=`echo "$bdfrec" | awk '{print $6}'`
		printf ",$fsMount\n" >> $tempdir/$scrname.nfsdev.$server
    else
        SplitLines=N
        fsKbytes=`echo "$bdfrec" | awk '{print $1}'`
        fsUsed=`echo "$bdfrec" | awk '{print $2}'`
        fsAvail=`echo "$bdfrec" | awk '{print $3}'`
        fsPctUsed=`echo "$bdfrec" | awk '{print $4}'|sed "s/%//g"`
        fsMount=`echo "$bdfrec" | awk '{print $5}'`
		printf ",$fsMount\n" >> $tempdir/$scrname.nfsdev.$server
    fi

	if ! echo $fsMount | egrep '^/home/[A-Za-z]+[-A-Za-z0-9_]*$'
	then
        echo "$fsPctUsed $fsAvail $NASorNFS $fsMount" >> $tempdir/$scrname.all
    fi

done
if [ -s $tempdir/$scrname.nfsdev.$server ]  
then
   cat $tempdir/$scrname.nfsdev.$server | awk -F, '$3 !~ /^\/home/' > $tempdir/$scrname.nfsdev.$server.tmp
   mv $tempdir/$scrname.nfsdev.$server.tmp $tempdir/$scrname.nfsdev.$server
fi
fi
fi

cat $tempdir/$scrname.all | while read bdfrec 
do
	fspct=`echo "$bdfrec" | awk '{print $1}'`
	fsfree=`echo "$bdfrec" | awk '{print $2}'`
	fsNFS=`echo "$bdfrec" | awk '{print $3}'`
	fsName=`echo "$bdfrec" | awk '{print $4}'`

	echo "$fsName $NASorNFS at ${fspct}% with ${fsfree}K free" 

	if [ $fspct -ge $mailTH ]
	then
	    echo "$fsName $fsNFS at ${fspct}%" >> $tempdir/$scrname.warn
	fi
done

if [ ! -f $tempdir/$scrname.warn.prev ]
then
    cp -p $tempdir/$scrname.warn $tempdir/$scrname.warn.prev > /dev/null 2>&1 
fi

if [ ! -f $tempdir/$scrname.all.prev ]
then
    cp -p $tempdir/$scrname.all $tempdir/$scrname.all.prev > /dev/null 2>&1 
fi

####  Now check to see if there are any new filesystem problems  ####

diff $tempdir/$scrname.warn.prev $tempdir/$scrname.warn | \
	grep "^>" | cut -c 3- | sort -u | egrep -v $EXCLUDEFS \
	> $tempdir/$scrname.warn.changes
rm $tempdir/$scrname.warn.delta > /dev/null 2>&1
rm $tempdir/$scrname.cleared.delta > /dev/null 2>&1

if [ -s $tempdir/$scrname.warn.changes -o -s $tempdir/$scrname.cleared.changes ]
then
    echo "*** Filesystem percentage changes detected ***"
else
    exit 0
fi

#### Gen the "warning" delta for filesystems growing and exceeding the email threshhold.... ####

cat $tempdir/$scrname.warn.changes | while read fsrec
do
    echo
    echo "$fsrec"
    sendpage=Y
    fsname=`echo "$fsrec" | awk '{print $1}'`
    fspct=`echo "$fsrec" | awk '{print $4}'|awk -F% '{print $1}'`
    fsfree=`grep " $fsname$" $tempdir/$scrname.all | awk '{print $2}'`
    if [ $fspct -lt $pageTH ]
    then
        sendpage=N
    fi

#### $fsname must have been a valid filesystem in last run. #####

    if grep -q " $fsname$" $tempdir/$scrname.all.prev
    then
		fspctprev=`grep " $fsname$" $tempdir/$scrname.all.prev | awk '{print $1}'`
                echo "fspctprev=$fspctprev"
		#       see if $fsname is in the exceptions file
		#  Global exception for CIFS filesystems

        if [ -O $fsname ]
		then
		 cd $fsname > /dev/null 2>&1
		 if	[ $? -ne 0 ] 
		 then
		 echo "$fsname: is a CIFS filesystem. skipping."
		 continue
		 fi
    	fi

		#  Regular on-off exceptions in the exceptions file
		if [ -s $ExceptFileLoc ]
		then
		   cat $ExceptFileLoc | grep $server > $tempdir/$scrname.exceptions
		   if grep -q ":$fsname:" $tempdir/$scrname.exceptions
		    then
		        if grep ":$fsname:" $tempdir/$scrname.exceptions | grep -q ":email-only"
		        then 
				    sendpage=N
				else
					echo "$fsname: is in the exceptions file. skipping."
					continue
				fi
			fi
		fi

		# filesystem utilization must have increased since last run
		if [ $fspct -gt $fspctprev ]
		then
		    echo "$fsname is going to the warning delta file."
		    fsowner=`ls -ld $fsname | awk '{print $3}'`
		    echo "$fsrec with ${fsfree}K free   owner=$fsowner pagable=$sendpage" \
				>> $tempdir/$scrname.warn.delta
		fi
    else
		echo "$fsname was *not* a valid filesystem in last run. skipping."
    fi
done

echo "checking warn delta..."

#########################################################
# Always send an email based on the server name
#  Filesystems that have reached warning threshholds
#########################################################

if [ -s $tempdir/$scrname.warn.delta ]
then
    echo
    echo "Filesystems reaching capacity:"
    echo
    cat $tempdir/$scrname.warn.delta

    # Now loop thru the delta file and gen the appropriate OVO messages
    cat $tempdir/$scrname.warn.delta | while read ovorec
    do
        fsname=`echo "$ovorec" | awk '{print $1}'`
        fscap=`echo "$ovorec" | awk '{print $4}'`
        fsfree=`echo "$ovorec" | awk '{print $6}'`
        fsNFS=`echo "$ovorec" | awk '{print $2}'`
        fsowner=`echo "$ovorec" | awk -F"owner=" '{print $2}' | awk '{print $1}'`
        fspage=`echo "$ovorec" | awk -F"pagable=" '{print $2}' | awk '{print $1}'`

        # zstat log file cleanup
		if [ $fsname = "/var" ]
		then
   		  bSize=`ls -l $ZSLOG | awk '{print $5}'`
		  gSize=$(($bSize/1073741824))
		  [ $gSize -ge $ZSLOGTHRESH ] && $SVCADMBIN restart zstat
	      continue
		fi

        [ "$fsNFS" = "N" ] && OVOmsg=`echo "Filesystem Alert: $fsname owned by $fsowner is at $fscap capacity with $fsfree free."`
        if [ "$fsNFS" = "Y" ] 
		then
		 fsdev=`grep ",$fsname$" $tempdir/$scrname.nfsdev.$server | cut -f 1 -d,`
		 if [ "$fsowner" = "root" ]
		 then
		  rfsowner=`ls -ld /$fsname/* |grep -v "lost+found" | awk '{print $3}' | sort | uniq | sed '/^[0-9][0-9]*/d' | awk '{printf $1 " "}'`
		  if [ -z "$rfsowner" ]
		  then
		   fsowner="unknown"
			 if [ `echo $fsdev | awk '/^[A-Za-z]+.*:\/[A-Za-z]+.*/'` ]
		     then
		        OVOmsg=`echo "NAS Volume Alert: NAS volume $fsdev ( mounted as $fsname on $server ) is at $fscap capacity with $fsfree free."`
				if [ -s $tempdir/$scrname.nasvolumes ] 
				then
				   nasmnthosts=`cat $tempdir/$scrname.nasvolumes | grep "^$fsdev;" | cut -f 2 -d';'`
				   [ -n $nasmnthosts ] && nas1host=`echo $nasmnthosts | cut -f 1 -d,`
                fi
				[ "$nas1host" = "$server" ] &&  [ `echo $nasmnthosts  | awk -F, '{print NF}'` -gt 1 ] && OVOmsg="$OVOmsg *** ITOC please note: This NAS Volume is mounted on following multiple hosts:$nasmnthosts, please ensure only one IM was created for the same volume if you receive multiple alerts ***"   
                else
		        OVOmsg=`echo "Filesystem Alert: $fsname is at $fscap capacity with $fsfree free."`
             fi
		  else
		   if [ "`echo $rfsowner | grep root`" ]
		   then
		    fsowner="root"
		   else
		    fsowner=`echo $rfsowner | awk '{print $1}'`
		   fi
			 if [ `echo $fsdev | awk '/^[A-Za-z]+.*:\/[A-Za-z]+.*/'` ]
			 then
		       OVOmsg=`echo "NAS Volume Alert: NAS volume $fsdev ( mounted as $fsname on $server ) owned by the following user(s): $rfsowner is at $fscap capacity with $fsfree free."`
			   if [ -s $tempdir/$scrname.nasvolumes ] 
			   then
				 nasmnthosts=`cat $tempdir/$scrname.nasvolumes | grep "^$fsdev;" | cut -f 2 -d';'`
				 [ -n $nasmnthosts ] && nas1host=`echo $nasmnthosts | cut -f 1 -d,`
               fi
			   [ "$nas1host" = "$server" ] &&  && [ `echo $nasmnthosts  | awk -F, '{print NF}'` -gt 1 ] && OVOmsg="$OVOmsg *** ITOC please note: This NAS Volume is mounted on following multiple hosts:$nasmnthosts, please ensure only one IM was created for the same volume if you receive multiple alerts ***"   
             else
		       OVOmsg=`echo "Filesystem Alert: NFS file system $fsname owned by the following user(s): $rfsowner is at $fscap capacity with $fsfree free."`
             fi
		  fi
		 else
			if [ `echo $fsdev | awk '/^[A-Za-z]+.*:\/[A-Za-z]+.*/'` ]
			then
		      OVOmsg=`echo "NAS Volume Alert: NAS volume $fsdev ( mounted as $fsname on $server ) owned by $fsowner is at $fscap capacity with $fsfree free."`
			  if [ -s $tempdir/$scrname.nasvolumes ] 
			  then
				 nasmnthosts=`cat $tempdir/$scrname.nasvolumes | grep "^$fsdev;" | cut -f 2 -d';'`
				 [ -n $nasmnthosts ] && nas1host=`echo $nasmnthosts | cut -f 1 -d,`
              fi
			  [ "$nas1host" = "$server" ] && [ `echo $nasmnthosts  | awk -F, '{print NF}'` -gt 1 ] && OVOmsg="$OVOmsg *** ITOC please note: This NAS Volume is mounted on following multiple hosts:$nasmnthosts, please ensure only one IM was created for the same volume if you receive multiple alerts ***"   
            else
			  OVOmsg=`echo "Filesystem Alert: NFS file system $fsname owned by $fsowner is at $fscap capacity with $fsfree free."`
            fi
         fi
		fi
        fsrec="$OVOmsg"

	    if [ "$fspage" = "Y" ]
        then
           OVOsev=critical
        else
           OVOsev=major
        fi

	    OVOgrp=ITOC-TIER-2-UNIX
	    MAILgrp=UNIXmail
	    NOopcmsg=N

   case "$fsowner" in 

   ###########################################################
   # If filesystem is owned by oracle, log it and move on
   ##########################################################

   oracle|oradba|1003|280|orasbgh)     OVOgrp="&cegoradba"
      if echo "$fsname" | grep -q -e "^/restore" -e "^/backups" -e "^/tmp-backups"
      then
         NOopcmsg=Y
      else
         NOopcmsg=Y
         Details="$fsname at $fspct% capacity, no messages sent"
	     echo "${DATE}: $Details" >> $oraclelog
      fi
   ;;

   # If filesystem is owned by applmgr, determine BU and page accordingly

   applmgr|applshdw)                OVOgrp="&oraclefin"
      if [[ "$ServerDataCBP" = "CCG" ]]
      then
		 OVOgrp="&CCGFIN";  MAILgrp="Scorpio"
      else
		 OVOgrp="&oraclefin";   MAILgrp="BISai"
      fi
   ;;

   # If filesystem is owned by e46467 and is /CERdw, page accordingly

   e46467)                OVOgrp="&CERcoretech"
      if [[ "$fsname" = "/CERdw" ]]
      then
         NOopcmsg=Y
		 OVOgrp="&CERcoretech";  MAILgrp="CERInt"
      fi
   ;;

   # If filesystem is owned by given user, tell appropriate Team

   advxrt)	                OVOgrp="BGEHomeCriticalApps";      MAILgrp="BGEHome";;
   anm)  	                OVOgrp="DataServices";             MAILgrp="DataServices";;
   archive)	                OVOgrp="CustomerServicesSupport";  MAILgrp="OnDemand";;
   ccbmgr|ccbmgt|oubiadmin|oubi) OVOgrp="BGECCBTech";               MAILgrp="CCB";;
   ccbconv|ccbsftp)	        OVOgrp="BGECCBTech";               MAILgrp="CCB";;
   dmadmin)	                OVOgrp="Documentum";               MAILgrp="DCTMadm";;
   dmis)                    OVOgrp="DMIS";                     MAILgrp="DMIS";;
   maxadmin)                OVOgrp="CCGMaximoIT";              MAILgrp="MAXADMIN";;
   nbackup)                 OVOgrp="Backup";                   MAILgrp="BACKUPmail";;
   oms*|pdm*|ptpdm|spl)     OVOgrp="OMS";                      MAILgrp="OMSts";;
    ces*|modeladm|bge)      OVOgrp="OMS";                      MAILgrp="OMSts";;
    test_bge|test_ces)      OVOgrp="OMS";                      MAILgrp="OMSts";;
    dev1|dev2pdm|dev3|dev5) OVOgrp="OMS";                      MAILgrp="OMSts";;
   planadm)                 OVOgrp="OracleFin";                MAILgrp="PYXIS";;
   procmon|procwww)         OVOgrp="CERArchitecture";          MAILgrp="CCGcore";;
   limce|limfoit)           OVOgrp="CERArchitecture";          MAILgrp="CCGcore";;
   #mitg)                    OVOgrp="PORTAL";                   MAILgrp="PRTL";;
   #aiamgr)                  OVOgrp="PORTAL";                   MAILgrp="PRTL";;
   psoft)                   OVOgrp="PeopleConnectIA";          MAILgrp="PSOFT";;
   sas|sasdev|sasuat)       OVOgrp="SAS";                      MAILgrp="SAS";;
   smallwd)	                OVOgrp="Atlas";                    MAILgrp="ATLAS";;
   sybase)                  OVOgrp="CEROracleDBA";             MAILgrp="CER1";;
   tibadmin)	            OVOgrp="tibco";                    MAILgrp="TIBCO";;
   timeadmn)                OVOgrp="Pyxis";                    MAILgrp="IATeam";;
   vigadmin|wingadmn|ldap)  OVOgrp="PORTAL";                   MAILgrp="PRTL";;

   # If filesystem is owned by root

   root|bin|adm)		OVOgrp="ITOC-TIER-2-UNIX"
      if echo "$fsname" | grep -q -e "^/home" -e "^/hphome" -e "^/data" -e "^/sw" -e "^/bld" \
		 -e "^/restore" -e "^/backups" -e "^/tmp-backups"
      then
         cat $tempdir/$scrname.warn.changes | grep $fsname > $tempdir/$scrname.nfs
         NOopcmsg=`cat $tempdir/$scrname.nfs | awk '{print $2}'`
      fi
   ;;

   # Inform NOC to page appropriate application group

   *)		OVOgrp="appropriate-application-team"
   ;;
   esac 

   export OVOgrp; export MAILgrp
   OVOmsg="$OVOmsg  Please open an SDE ticket and page the \"$OVOgrp\" group to correct."
   if [ "$NOopcmsg" = "N" ]
   then
	  Details="$fsname at $fspct% capacity, opcmsg sent, sev=$OVOsev, mgs_grp=${OVOgrp}"
	  if [ "$OVOsev" = "critical" ]
	  then
	  `/opt/OV/bin/OpC/opcmsg sev="$OVOsev" app="UNIX" obj="$fsname" msg_text="$OVOmsg" msg_grp=\"${OVOgrp}\"`
	  fi
	  echo "${DATE}: $Details" >> $alertlog
   fi
   done
fi

#################################
# Cleanup and Miscellaneous
################################

rm -f ${LOCKFILE}
exit 0
