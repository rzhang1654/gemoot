#!/usr/bin/bash
INPUTDIR="/var/bsc/build"
DHCPCONF="/var/bsc/build/custom/dhcp-conso."
declare -a capsules=("caplnxbup-001.exelonds.com" "caplnxbup-002.exelonds.com" "caplnxbup-003.exelonds.com" "nzp01-c-02v.excld.com" "nzp01-o-02v.excld.com")
HAMMERBIN="/usr/bin/hammer"
TDATE=`date +"%Y-%m-%d"`
HEAD="source"
LIST="list"
TAIL="in1"
TAILF="in"
OLD="old"
CUR="current"
DHCP="dhcpsub"
CUSTOM="custom"
CONF="conf1"
#VERMED="vermed"
SECTION=("location" "partition-table" "subnet" "hostgroup" "host")
itr=0
#[ -s ${INPUTDIR}/${HEAD}.${VERMED}.${TAIL} ] && rm -f ${INPUTDIR}/${HEAD}.${VERMED}.${TAIL}
while (( $itr < ${#SECTION[@]} ))
do
#cat ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${CUR} | awk 'NR==2 {print $0,"|"}' | sed 's/ *| */|/g' > ${INPUTDIR}/${CUSTOM}/${SECTION[$itr]}.${CONF}
printf "checking ${SECTION[$itr]} ...\n"
${HAMMERBIN} ${SECTION[$itr]} ${LIST} > ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${CUR}
sed '{
1,3d
$d
s/ *| */|/g
s/ +$//g
}' ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${CUR} > ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAIL}
cp ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${CUR} ${INPUTDIR}/${OLD}/${HEAD}.${SECTION[$itr]}.${TDATE}
[ "${SECTION[$itr]}" = "host" ] && cat ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAIL} | awk -F "|" '{print $1"|"$2"|"$3"|"$4"|"$5"|"$6}' > ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAILF} 
[ "${SECTION[$itr]}" = "location" ] && cat ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAIL} | awk -F "|" '{print $1"|"$3}' > ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAILF}
[ "${SECTION[$itr]}" = "subnet" ] && cat ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAIL} | awk -F "|" '{print $1"|"$2"|"$3"|"$5}' > ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAILF}
[ "${SECTION[$itr]}" = "hostgroup" ] && cat ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAIL} | awk -F "|" '{print $1"|"$2"|"$3"|"$4"|"$5"|"$6}' > ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAILF}
[ "${SECTION[$itr]}" = "partition-table" ] && cat ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAIL} | awk -F "|" '/Exelon/ {print $1"|"$2"|"$3}' > ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAILF}
rm -f ${INPUTDIR}/${HEAD}.${SECTION[$itr]}.${TAIL}
(( itr=$itr+1 ))
done
printf "checking dhcp ...\n"
cat /dev/null > ${INPUTDIR}/${HEAD}.${DHCP}.${CUR}
for capsule in "${capsules[@]}"
do
cat "${DHCPCONF}${capsule}" | awk '/^subnet/ {if ($2 ~ /[0-9]*\.[0-9]*\.[0-9]*\.0/) {print $2}}' | sort | uniq >> ${INPUTDIR}/${HEAD}.${DHCP}.${CUR}
done
#cp ${INPUTDIR}/${HEAD}.${DHCP}.${CUR} ${INPUTDIR}/${HEAD}.${DHCP}.${TAILF}
[ -s ${INPUTDIR}/${HEAD}.${DHCP}.${CUR} ] && cat ${INPUTDIR}/${HEAD}.${DHCP}.${CUR} | sort |uniq > ${INPUTDIR}/${HEAD}.${DHCP}.${TAILF}
[ -s ${INPUTDIR}/${HEAD}.${DHCP}.${TAILF} ] && mv ${INPUTDIR}/${HEAD}.${DHCP}.${CUR} ${INPUTDIR}/${OLD}/${HEAD}.${DHCP}.${TDATE}
#printf "checking version ...\n"
#for i in `cut -f 1 -d '|' ${INPUTDIR}/${HEAD}.${SECTION[3]}.${TAIL}`
#do
#j=`${HAMMERBIN} ${SECTION[3]} info --id $i | sed -n "s/^Path:.*\/\([6-9]\.[0-9][0-9]*\)\/.*$/\1/p"`
#printf "$i|$j\n" >> ${INPUTDIR}/${HEAD}.${VERMED}.${TAIL}
#done
printf "\n\n"


